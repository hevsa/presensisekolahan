<link rel="apple-touch-icon" sizes="76x76" href="<?= base_url('public/assets/img/apple-icon.png'); ?>">
<link rel="icon" type="image/png" href="<?= base_url('public/assets/img/favicon.png'); ?>">

<!-- CSS Files -->
<link href="<?= base_url('public/assets/fonts/fonts.css'); ?>" rel="stylesheet" />
<link href="<?= base_url('public/assets/css/material-dashboard.css'); ?>" rel="stylesheet" />
<link href="<?= base_url('public/assets/css/fontawesome.min.css'); ?>" rel="stylesheet">

<!-- CSS Just for demo purpose, don't include it in your project -->
<link href="<?= base_url('public/assets/demo/demo.css'); ?>" rel="stylesheet" />