<footer class="footer">
   <div class="container-fluid">
      <nav class="float-left">
         <ul>
            <li>
               <a href="https://www.instagram.com/ikhsan3adi/">
                  Instagram
               </a>
            </li>
         </ul>
      </nav>
      <div class="copyright float-right">
         &copy;
         2023
         <!-- <script>
                document.write(new Date().getFullYear())
            </script> -->
         <!-- , made with <i class="material-icons">favorite</i> by
            <a href="https://www.instagram.com/ikhsan3adi/" target="_blank">Ikhsan S.</a> -->
      </div>
   </div>
</footer>