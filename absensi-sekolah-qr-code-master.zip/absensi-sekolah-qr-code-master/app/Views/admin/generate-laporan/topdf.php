<script>
   window.print();
</script>